import { useState, type ReactNode } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Clock3,
  MapPin,
  Menu,
  Music2,
  Phone,
  Star,
  X,
} from "lucide-react";

const address = "R. Dr. Aristídes de Oliveira, 13 - Q-K - Santa Mônica, Salvador - BA, 40015-200";
const phone = "+55 71 99955-5603";
const phoneLink = "tel:+5571999555603";
const directionsLink = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;
const mapEmbedLink = `https://maps.google.com/maps?q=${encodeURIComponent(address)}&z=15&output=embed`;
const reviewLink = "https://www.google.com/search?q=Petiscaria+%26+Bar+La+Bodega+Salvador";

function Brand({ light = false }: { light?: boolean }) {
  return (
    <a className={`brand ${light ? "brand-light" : ""}`} href="#inicio" aria-label="La Bodega — início">
      <img className="brand-image" src="/la-bodega-logo.png" alt="" />
      <span className="brand-type">
        <span className="brand-name">LA BODEGA</span>
        <span className="brand-caption">PETISCARIA · SALVADOR</span>
      </span>
    </a>
  );
}

function Eyebrow({ children }: { children: ReactNode }) {
  return <div className="eyebrow"><span className="eyebrow-line" />{children}</div>;
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <main id="inicio">
      <div className="announcement">
        <span className="announcement-dot" />
        <span>Petisco bom, música boa e Salvador no coração.</span>
        <a href={phoneLink}>Fale com a gente <ArrowRight size={13} /></a>
      </div>

      <header className="site-header">
        <div className="header-inner">
          <Brand />
          <button className="mobile-menu-toggle" type="button" aria-label={menuOpen ? "Fechar menu" : "Abrir menu"} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <nav className={`main-nav ${menuOpen ? "nav-open" : ""}`} aria-label="Navegação principal">
            <a href="#casa" onClick={closeMenu}>A casa</a>
            <a href="#sabores" onClick={closeMenu}>Sabores</a>
            <a href="#som" onClick={closeMenu}>Música & ambiente</a>
            <a href="#visite" onClick={closeMenu}>Como chegar</a>
            <a className="nav-cta" href={phoneLink}><Phone size={14} /> Ligar agora</a>
          </nav>
        </div>
      </header>

      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-copy">
          <Eyebrow>UM BOM ENCONTRO EM SALVADOR</Eyebrow>
          <h1 id="hero-title">A noite fica<br />melhor <em>à mesa.</em></h1>
          <p className="hero-description">Petiscos de qualidade, cerveja gelada e música que dá vontade de ficar mais um pouco. Chegue com fome. A gente cuida do clima.</p>
          <div className="hero-actions">
            <a className="button button-primary" href="#sabores">Conheça a casa <ArrowDown size={16} /></a>
            <a className="button button-text" href={directionsLink} target="_blank" rel="noreferrer">Como chegar <ArrowUpRight size={16} /></a>
          </div>
          <div className="hero-proof">
            <a className="rating-pill" href={reviewLink} target="_blank" rel="noreferrer" aria-label="Ver avaliação e opiniões no Google">
              <span className="rating-stars" aria-hidden="true"><Star /><Star /><Star /><Star /><Star /></span>
              <strong>4,9</strong><span className="rating-separator" /><span>30 opiniões no Google</span><ArrowUpRight size={13} />
            </a>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-photo-frame">
            <img src="/petiscos-hero.webp" alt="Petiscos servidos à mesa em uma atmosfera acolhedora de bar" fetchPriority="high" />
            <div className="photo-caption"><span className="caption-dot" /> FEITO PRA COMPARTILHAR</div>
          </div>
          <div className="hero-stamp" aria-label="Petiscaria em Salvador">
            <span className="stamp-top">BOA COMIDA</span>
            <span className="stamp-center">B</span>
            <span className="stamp-bottom">BOA MÚSICA</span>
          </div>
          <div className="hero-side-note">SANTA MÔNICA <span>·</span> SALVADOR, BA</div>
        </div>
        <a className="scroll-cue" href="#casa" aria-label="Role para conhecer a casa"><span /> DESÇA E SINTA O CLIMA</a>
      </section>

      <section className="intro-section" id="casa">
        <div className="intro-label"><span>01</span><span className="intro-label-line" /> A CASA</div>
        <div className="intro-content">
          <div className="intro-heading">
            <Eyebrow>UM LUGAR PRA CHAMAR DE SEU</Eyebrow>
            <h2>Tem coisa que<br />só acontece <em>junto.</em></h2>
          </div>
          <div className="intro-copy">
            <p>A La Bodega é uma petiscaria e bar de família. Um encontro de bons sabores, cerveja gelada e música — do tipo que transforma uma saída qualquer numa noite especial.</p>
            <p>Na mesa ou na pista, o convite é o mesmo: reunir quem você gosta e aproveitar Salvador do jeito mais gostoso.</p>
            <a className="underlined-link" href="#visite">Venha conhecer <ArrowRight size={15} /></a>
          </div>
        </div>
        <div className="intro-marquee" aria-hidden="true"><div>DE BEM COM A NOITE <span>✳</span> DE BEM COM A NOITE <span>✳</span> DE BEM COM A NOITE <span>✳</span> DE BEM COM A NOITE <span>✳</span></div></div>
      </section>

      <section className="tastes-section" id="sabores">
        <div className="section-topline"><Eyebrow>DA COZINHA PRA SUA MESA</Eyebrow><span>02 / SABORES DA CASA</span></div>
        <div className="tastes-heading-row">
          <h2>Peça mais um.<br /><em>É pra dividir.</em></h2>
          <p>Os favoritos da casa têm sabor de conversa boa e mesa cheia.</p>
        </div>
        <div className="food-feature">
          <div className="food-image-wrap">
            <img src="/petiscos-destaques.webp" alt="Petiscos dourados preparados para compartilhar" loading="lazy" />
            <span className="food-image-index">SABOR DE BOTECO, JEITO DA BODEGA</span>
          </div>
          <div className="food-list">
            <article className="food-item"><span className="food-number">01</span><div><h3>Passarinha do La Bodega</h3><p>Um dos destaques da casa.</p></div><span className="food-spark" aria-hidden="true">✳</span></article>
            <article className="food-item"><span className="food-number">02</span><div><h3>Camarão Encapotado</h3><p>Um favorito para pedir à mesa.</p></div><span className="food-spark" aria-hidden="true">✳</span></article>
            <div className="drinks-note"><span className="drinks-icon">✳</span><div><span className="drinks-overline">PRA ACOMPANHAR</span><p>Uma gelada do seu jeito.</p><div className="beer-tags"><span>Corona</span><span>Heineken</span></div></div></div>
            <p className="menu-note"><Check size={13} /> Consulte a disponibilidade dos itens diretamente com a casa.</p>
          </div>
        </div>
      </section>

      <section className="music-section" id="som">
        <div className="music-copy">
          <Eyebrow>03 / O SOM DA CASA</Eyebrow>
          <h2>Quando a música<br />começa, <em>a noite abre.</em></h2>
          <p>Apresentações ao vivo com músicos baianos e aquele clima gostoso de bar. A trilha passeia pela MPB — e se der vontade de dançar, tem espaço pra isso também.</p>
          <div className="music-tags"><span><Music2 size={14} /> Música ao vivo</span><span>MPB baiana</span><span>Espaço para dançar</span></div>
          <a className="music-contact" href={phoneLink}><Phone size={15} /> Consulte a programação pelo telefone <ArrowRight size={15} /></a>
        </div>
        <div className="music-art" aria-hidden="true">
          <div className="music-art-orbit orbit-one" /><div className="music-art-orbit orbit-two" />
          <div className="music-art-center"><Music2 size={42} strokeWidth={1.2} /><span>NOITE<br />BOA</span></div>
          <span className="music-art-word word-top">AO VIVO · EM SALVADOR</span>
          <span className="music-art-word word-bottom">MPB &amp; BOAS HISTÓRIAS</span>
          <span className="music-art-star star-a">✳</span><span className="music-art-star star-b">✳</span><span className="music-art-star star-c">✦</span>
        </div>
        <div className="music-ticker" aria-hidden="true"><span>COMIDA NO BAR</span><span>✳</span><span>MÚSICA AO VIVO</span><span>✳</span><span>BORA DANÇAR</span><span>✳</span><span>COMIDA NO BAR</span></div>
      </section>

      <section className="visit-section" id="visite">
        <div className="visit-title-block">
          <Eyebrow>04 / ESPERAMOS VOCÊ</Eyebrow>
          <h2>Seu lugar<br />é <em>à mesa.</em></h2>
          <p>Estamos em Santa Mônica. Vai ser bom receber você.</p>
          <a className="button button-light" href={directionsLink} target="_blank" rel="noreferrer">Traçar rota <ArrowUpRight size={16} /></a>
        </div>
        <div className="visit-info">
          <div className="visit-detail"><span className="detail-icon"><MapPin size={18} /></span><div><span className="detail-label">NOSSO ENDEREÇO</span><p>{address}</p><a href={directionsLink} target="_blank" rel="noreferrer">Abrir no Google Maps <ArrowUpRight size={13} /></a></div></div>
          <div className="visit-detail"><span className="detail-icon"><Phone size={18} /></span><div><span className="detail-label">FALE COM A GENTE</span><a className="phone-number" href={phoneLink}>{phone}</a><span className="detail-sub">Toque para ligar</span></div></div>
          <div className="visit-detail"><span className="detail-icon"><Clock3 size={18} /></span><div><span className="detail-label">HORÁRIO</span><p>Os horários podem variar. Ligue para confirmar o funcionamento e a programação do dia.</p><a href={phoneLink}>Confirme por telefone <ArrowRight size={13} /></a></div></div>
        </div>
        <div className="visit-map">
          <iframe title="Mapa da La Bodega em Santa Mônica, Salvador" src={mapEmbedLink} loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
          <a className="map-open" href={directionsLink} target="_blank" rel="noreferrer">ABRIR MAPA <ArrowUpRight size={14} /></a>
        </div>
      </section>

      <section className="last-call">
        <span className="last-call-flower" aria-hidden="true">✳</span>
        <p>A mesa fica melhor <em>com você.</em></p>
        <a href={phoneLink}>Ligue e venha <ArrowRight size={15} /></a>
      </section>

      <footer className="site-footer">
        <div className="footer-top"><Brand light /><div className="footer-motto">PETISCO BOM. MÚSICA BOA.<br />A VIDA ACONTECE À MESA.</div><a className="back-top" href="#inicio">VOLTAR AO TOPO <ChevronDown size={15} /></a></div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} La Bodega · Salvador, Bahia</span><span>R. Dr. Aristídes de Oliveira, Santa Mônica</span><a href={phoneLink}>{phone}</a></div>
      </footer>
      <a className="floating-call" href={phoneLink} aria-label={`Ligar para La Bodega no ${phone}`}><Phone size={19} /><span>Ligar</span></a>
    </main>
  );
}

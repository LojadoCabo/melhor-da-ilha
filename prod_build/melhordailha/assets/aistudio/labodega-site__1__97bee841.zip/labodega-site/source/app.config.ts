export default { logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663971597983/BQcatUwDOczeSoaa.png" };
